var config = {
    'map': {
        '*': {
            enhanced_ecommerce : 'Tatvic_ActionableGoogleAnalytics/js/enhanced_ecommerce',
            analytics_script : 'Tatvic_ActionableGoogleAnalytics/js/analyticsscript',
            gtag_script: 'Tatvic_ActionableGoogleAnalytics/js/gtagscript',
            both_script: 'Tatvic_ActionableGoogleAnalytics/js/bothscript',
            ga4_script: 'Tatvic_ActionableGoogleAnalytics/js/ga4script'
        }
    }
};
