<?php
/**
 * Copyright © MageWorx. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageWorx\OrderEditor\Model\ResourceModel;

use Magento\Sales\Model\ResourceModel\Order\Invoice as OriginalResourceModel;

/**
 * Class Invoice
 */
class Invoice extends OriginalResourceModel
{

}
