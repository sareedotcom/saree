# Sticky Notification Bar - Magento 2 Extension

[![Latest Stable Version](https://img.shields.io/packagist/v/redchamps/module-notification-bar.svg?style=flat-square)](https://packagist.org/packages/redchamps/module-notification-bar)  [![Packagist](https://img.shields.io/packagist/dt/redchamps/module-notification-bar.svg?style=flat-square)](https://packagist.org/packages/redchamps/module-notification-bar/stats) [![Packagist](https://img.shields.io/packagist/dm/redchamps/module-notification-bar.svg?style=flat-square)](https://packagist.org/packages/redchamps/module-notification-bar/stats)

This will display a sticky notification bar on top of website.


## Installation

> composer require redchamps/module-notification-bar

## Authors

- RedChamps [Maintainer] [![Twitter Follow](https://img.shields.io/twitter/follow/_redChamps.svg?style=social)](https://twitter.com/_redChamps)
- Ravinder [Maintainer] [![Twitter Follow](https://img.shields.io/twitter/follow/_iAmRav.svg?style=social)](https://twitter.com/_iAmRav)


## License

This project is licensed under the Open Source License

## ADS

Please visit our [store](https://redchamps.com) for more free/paid extensions from us.
