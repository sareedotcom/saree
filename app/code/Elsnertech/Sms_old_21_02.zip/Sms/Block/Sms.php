<?php
namespace Elsnertech\Sms\Block;
 
class Sms extends \Magento\Framework\View\Element\Template
{
    public function getSmsTxt()
    {
        return 'Sms';
    }
}