// JavaScript Document
var config = {
    map: {
        '*': {
           script : 'Elsnertech_Sms/js/script'
        }
    }
};