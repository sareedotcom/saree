var config =
{
    map:
    {
        '*':
        {
            'Magento_Checkout/js/view/payment/default': 'Logicrays_CodOrderManagement/js/view/payment/default'
        }
    }
};