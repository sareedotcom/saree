<?php
/**
 * @category Mageants GiftCertificate
 * @package Mageants_GiftCertificate
 * @copyright Copyright (c) 2016 Rock Technolabs
 * @author Mageants Team <info@Mageants.com>
 */
 
namespace Mageants\GiftCertificate\Block\Adminhtml\Order\View;
/**
 * Custom class for set GiftCertification info in admin order view
 */ 
class Custom extends \Magento\Sales\Block\Adminhtml\Order\AbstractOrder
{

}
