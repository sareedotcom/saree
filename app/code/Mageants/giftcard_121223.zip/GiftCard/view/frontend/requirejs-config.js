 /**
  * Mageants GiftCard Magento2 Extension                           
  */
 var config = {
     map: {
         '*': {
             giftcertificate: 'Mageants_GiftCard/js/giftcertificate',
             'Magento_Checkout/template/minicart/item/default.html': 'Mageants_GiftCard/template/minicart/item/default.html'
         }
     }
 }