<?php
/**
 * @category Mageants GiftCard
 * @package Mageants_GiftCard
 * @copyright Copyright (c) 2016 Rock Technolabs
 * @author Mageants Team <info@Mageants.com>
 */
 
namespace Mageants\GiftCard\Block\Adminhtml\Order\View;

/**
 * Custom class for set GiftCard info in admin order view
 */
class Custom extends \Magento\Sales\Block\Adminhtml\Order\AbstractOrder
{
    
}
