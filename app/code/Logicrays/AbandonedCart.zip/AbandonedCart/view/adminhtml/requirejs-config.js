var config = 
{
    map: 
    {
        '*': 
        {
            'mage/adminhtml/grid':'Logicrays_AbandonedCart/js/grid',
            'Magento_Ui/js/form/components/tab_group':'Logicrays_AbandonedCart/js/form/components/tab_group',
            'Magento_Ui/js/grid/columns/actions':'Logicrays_AbandonedCart/js/grid/columns/actions',
            'Magento_Ui/js/form/components/html':'Logicrays_AbandonedCart/js/form/components/html'
        }
    }
};