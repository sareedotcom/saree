<?xml version="1.0"?>
<config xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="urn:magento:module:Magento_Config:etc/system_file.xsd">
    <system>
        <tab id="vendor" translate="label" class="vendor" sortOrder="100">
            <label>Logicrays</label>
        </tab>
        <section id="orderdelivery" translate="label" type="text" sortOrder="40" showInDefault="1" showInWebsite="1" showInStore="1">
            <class>separator-top</class>
            <label>Order Delivery</label>
            <tab>vendor</tab>
            <resource>Logicrays_OrderDeliveryEstimation::config_extension</resource>
            <group id="order" translate="label" type="text" sortOrder="20" showInDefault="1" showInWebsite="1" showInStore="1">
                <label>Holiday Configuration</label>
                <field id="enable" translate="label" type="select" sortOrder="1" showInDefault="1" showInWebsite="0" showInStore="0">
                    <label>Enable Module</label>
                    <source_model>Magento\Config\Model\Config\Source\Enabledisable</source_model>
                </field>
                <field id="holiday" translate="label" type="multiselect" sortOrder="30" showInDefault="1" showInWebsite="0" showInStore="0">
                    <label>Holiday</label>
                    <depends>
                        <field id="orderdelivery/order/enable">1</field>
                    </depends>
                    <source_model>Logicrays\OrderDeliveryEstimation\Model\Config\Source\ConfigOption</source_model>
                </field>
            </group>
        </section>
    </system>
</config>
