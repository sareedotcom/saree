<?php

namespace Logicrays\UpdateOrder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Logicrays\UpdateOrder\Helper\Email;

class Sendmesermentlink implements ObserverInterface
{
    protected $logger;

    /**
     * @param LoggerInterface $logger
     * @param ResourceConnection $resource
     * @param ScopeConfigInterface $scopeConfig
     * @param Email $helper
     */
    public function __construct(
        LoggerInterface $logger,
        ResourceConnection $resource,
        ScopeConfigInterface $scopeConfig,
        Email $helper
    )
    {
        $this->logger = $logger;
        $this->_resource = $resource;
        $this->scopeConfig = $scopeConfig;
        $this->helper = $helper;
    }

    /**
     * Execute
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            $order = $observer->getEvent()->getOrder();
            $order->save();
            $items = $order->getItems();
            $isMailSend = 0;
            foreach ($items as $item) {
                $options = $item->getProductOptions();        
                if (isset($options['options']) && !empty($options['options'])) {        
                    foreach ($options['options'] as $option) {
                        if($option['print_value'] == "Later"){
                            $data['order_id'] = $order->getId();
                            $data['customerEmail'] = $order->getCustomerEmail();
                            $data['customerName'] = $order->getCustomerName();
                            $data['incrementId'] = $order->getIncrementId();
                            $isMailSend = 1;
                            break;
                        }
                    }
                }
            }

            if($isMailSend){
                $order->setState($order->getState())->setStatus("pending_measurement");
                $order->save();
                $this->helper->sendEmail($data);
            }
        } catch (\Exception $e) {
            $this->logger->info($e->getMessage());
        }
    }
}