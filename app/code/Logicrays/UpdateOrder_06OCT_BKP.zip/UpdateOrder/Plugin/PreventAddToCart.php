<?php

namespace Logicrays\UpdateOrder\Plugin;

use Magento\Checkout\Model\Cart;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResourceConnection;
use Magento\Customer\Model\Session;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Request\Http;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\LocalizedException;

class PreventAddToCart
{
    /**
     * @var \Magento\Framework\Controller\Result\RedirectFactory
     */
    protected $resultRedirectFactory;

    /**
     * @param Context $context
     */
    public function __construct(
        Context $context,
        ResourceConnection $resource,
        Session $customerSession,
        ManagerInterface $messageManager,
        UrlInterface $url,
        Http $request,
        StoreManagerInterface $storeManager
    ) {
        $this->resultRedirectFactory = $context->getResultRedirectFactory();
        $this->resource = $resource;
        $this->customerSession = $customerSession;
        $this->messageManager = $messageManager;
        $this->_url = $url;
        $this->request = $request;
        $this->storeManager = $storeManager;
    }

    public function beforeAddProduct(Cart $subject, $productInfo, $requestInfo = null)
    {
        if (!$this->customerSession->isLoggedIn()) {
            if(isset($requestInfo['options'])){
                foreach($requestInfo['options'] AS $val){
                    if($val){
                        $connection = $this->resource->getConnection();
                        $select = $connection->select()
                            ->from(
                                ['cpott' => 'catalog_product_option_type_title'],
                                ['title']
                            )
                            ->where(
                                "cpott.option_type_id = :option_type_id"
                            );
                        $bind = ['option_type_id'=>$val];
                        $optionTitle = $connection->fetchOne($select, $bind);
                        if($optionTitle == "Later"){
                            $loginUrl=$this->storeManager->getStore()->getBaseUrl()."customer/account/login";
                            $accUrl = $this->_url->getUrl($loginUrl);
                            if($loginUrl != '' && isset($loginUrl))
                            {
                                $accUrl = $this->_url->getUrl($loginUrl);
                                $this->request->setParam('return_url', $accUrl);
                                $this->request->setParam('stitching_later', true);
                                
                                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        
                                $customerSession = $objectManager->create('Magento\Customer\Model\Session');
                                $customerSession->setMyValue('test');
                                
                                
                                //throw new \Magento\Framework\Exception\StateException(__('Login is required for Custom Size: Later.'));
                            }
                            break;
                        }
                    }
                }
            }
        }
        return [$productInfo,$requestInfo];
    }
}