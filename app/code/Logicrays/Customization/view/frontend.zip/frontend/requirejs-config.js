var config = {
    map: {
        '*': {
            'promotion-modal': 'Logicrays_Customization/js/promotion-modal'
        }
    }
};