<?php

namespace MagicToolbox\MagicScroll\Block\Adminhtml\Settings\Edit\Tab;

/**
 * Promo tab
 *
 */
class Promo extends \Magento\Backend\Block\Template
{
    /**
     * @var string
     */
    protected $_template = 'MagicToolbox_MagicScroll::promo.phtml';
}
