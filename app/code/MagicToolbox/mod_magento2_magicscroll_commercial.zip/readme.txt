#######################################################

 Magic Scroll™
 Magento 2 module version v1.7.4 [v1.6.93:v2.0.55]

 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2023 Magic Toolbox

#######################################################

INSTALLATION:

1. Unzip the Magic Scroll extension for Magento 2.0.

2. Upload the 'app' folder to your Magento directory.

3. Login to the Magento Admin as an administrator.

4. Click [System > Web Setup Wizard] in the menu.

5. Click the [Component Manager] link.

6. Find the Magic Scroll extension in the list and select the [Enable] action.

7. Follow the instructions in the wizard until the process is complete (you will see 'Success' message).    

8. Adjust the Magic Scroll settings to suit your needs - go to the [Magic Toolbox > Magic Scroll] menu in the Magento admin panel.

9. Magic Scroll is ready to use!

