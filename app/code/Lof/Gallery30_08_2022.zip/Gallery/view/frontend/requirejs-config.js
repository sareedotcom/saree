var config = {
    map: {
        '*': {
            cpowlcarousel: 'Lof_Gallery/js/owl.carousel',
        }
    }
};