/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
 var config = {
 	shim: {
 		'Lof_Gallery/js/camera.min': {
 			'deps': ['jquery']
 		},
 		'Lof_Gallery/js/simple-scrollbar.min': {
 			'deps': ['jquery']
 		},
 		'Lof_Gallery/js/masonry.pkgd.min': {
 			'deps': ['jquery']
 		}
 	}
 };