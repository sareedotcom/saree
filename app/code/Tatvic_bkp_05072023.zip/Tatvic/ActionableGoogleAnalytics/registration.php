<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Tatvic_ActionableGoogleAnalytics',
    __DIR__
);
