# MageWorx Admin Order Editor Extension for Magento 2

## Upload the extension

See the corresponding section in the README file for the extension meta package