
var config = {
    map: {
        '*': {
            magicscroll: 'MagicToolbox_MagicScroll/js/script'
        }
    }
};
